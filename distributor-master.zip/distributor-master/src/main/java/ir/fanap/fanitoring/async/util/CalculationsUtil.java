package ir.fanap.fanitoring.async.util;

/**
 * @author Milad karami
 */
public class CalculationsUtil {

	public static String convertNumberToIEEE754SinglePrecision(double value) {
		String sign = value > 0 ? "0" : "1";
		int bitsVal = Float.floatToIntBits((float) Math.abs(value));
		String bitsString = Integer.toString(bitsVal, 2);
		int sizeDifference = 31 - bitsString.length();
		for (int i = 0; i < sizeDifference; i++) {
			bitsString = "0" + bitsString;
		}
		return sign + bitsString;
	}

	public static float convertIEEE754SinglePrecisionToNumber(String value) {
		int intBits = Integer.parseInt(value, 2);
		return Float.intBitsToFloat(intBits);
	}

	public static String convertTo16BitDecimal(int value) {
		String bitString = Integer.toBinaryString(0x10000 | value).substring(1);
		int sizeDifference = 16 - bitString.length();
		for (int i = 0; i < sizeDifference; i++) {
			bitString = "0" + bitString;
		}
		return bitString;
	}

	public static int convertDecimalToNumber(String bitString) {
		return Integer.parseInt(bitString, 2);
	}
}
