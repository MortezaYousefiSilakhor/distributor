package ir.fanap.fanitoring.async.messaging;

import ir.fanap.fanitoring.async.messaging.dto.MessageWrapperVO;

import java.io.UnsupportedEncodingException;

/**
 * @author Alieh Mohtashami on 12/24/17.
 */
public interface JMSClientSender extends JMSClient {
	/**
	 * send message to activeMQ
	 *
	 * @param messageWrapperVO message to send
	 * @throws UnsupportedEncodingException when converting data to byte has some problems
	 */
	void sendMessage(MessageWrapperVO messageWrapperVO) throws Exception;
}
