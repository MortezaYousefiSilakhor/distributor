package ir.fanap.fanitoring.async.messaging;

/**
 * @author Alireza Abedini on 9/19/17.
 */
public class ActiveMQConnectionConfig {
	private String username;
	private String password;
	private String activeMQUrl;
	private String inputUrl;
	private String outputUrl;

	public ActiveMQConnectionConfig() {
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getActiveMQUrl() {
		return activeMQUrl;
	}

	public void setActiveMQUrl(String activeMQUrl) {
		this.activeMQUrl = activeMQUrl;
	}

	public String getInputUrl() {
		return inputUrl;
	}

	public void setInputUrl(String inputUrl) {
		this.inputUrl = inputUrl;
	}

	public String getOutputUrl() {
		return outputUrl;
	}

	public void setOutputUrl(String outputUrl) {
		this.outputUrl = outputUrl;
	}
}
