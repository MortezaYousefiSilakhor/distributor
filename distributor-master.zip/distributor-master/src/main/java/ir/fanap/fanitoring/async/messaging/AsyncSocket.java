package ir.fanap.fanitoring.async.messaging;

import ir.fanap.fanitoring.async.messaging.dto.AsyncMessageType;
import ir.fanap.fanitoring.async.messaging.dto.ClientMessage;
import ir.fanap.fanitoring.async.messaging.dto.MessageWrapperVO;
import ir.fanap.fanitoring.async.messaging.dto.PeerMessage;
import ir.fanap.fanitoring.async.util.JsonUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.text.MessageFormat;

/**
 * @author Mohsen Ebrahimi
 * @author Alieh Mohtashami
 */

@WebSocket(maxTextMessageSize = 10 * 1024)
public class AsyncSocket {
	private final String queueName;
	protected Logger logger = LogManager.getLogger(this.getClass());
	protected ClientMessage clientMessage;
	protected Session session;
	protected boolean isRegistrationCompleted = false;
	private boolean isCommunicationCompleted = false;

	public AsyncSocket(String queueName) {
		this.queueName = queueName;
	}

	public Session getSession() {
		return session;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public Boolean getCommunicationCompleted() {
		return isCommunicationCompleted;
	}

	@OnWebSocketClose
	public void onClose(int statusCode, String reason) throws Exception {
		logger.warn(MessageFormat.format("[Web Socket] Connection closed (Queue {0}): Status code:{1}, Reason :{2}",
				queueName,
				statusCode,
				reason));
		this.isCommunicationCompleted = true;
		this.session = null;
	}

	@OnWebSocketConnect
	public void onConnect(Session session) {
		logger.info("[Web Socket] onConnect");
		isCommunicationCompleted = false;
		this.session = session;
	}

	@OnWebSocketMessage
	public void onMessage(String receivedMsg) {
		JSONObject js;
		ClientMessage clientMessage = JsonUtil.getObject(receivedMsg, ClientMessage.class);

		switch (clientMessage.getType()) {
			case AsyncMessageType.PING:
				logger.info("[Web Socket] PING step finished successfully");
				logger.info("[Web Socket] Trying to register device ...");
				PeerMessage peerInfoVO = new PeerMessage();
				peerInfoVO.setAppId("Vaadin Client " + Thread.currentThread().getId());
				peerInfoVO.setDeviceId(clientMessage.getContent());
				String peerInfoVOJson = JsonUtil.getJson(peerInfoVO);
				sendMessage(AsyncMessageType.DEVICE_REGISTER, peerInfoVOJson);
				break;
			case AsyncMessageType.DEVICE_REGISTER:
				logger.info("[Web Socket] Device was registered successfully");
				logger.info("[Web Socket] Trying to register server ...");
				js = new JSONObject();
				js.put("name", queueName);
				sendMessage(AsyncMessageType.SERVER_REGISTER, js.toJSONString());
				break;
			case AsyncMessageType.SERVER_REGISTER:
				logger.info("[Web Socket] Server was registered successfully");
				logger.info("[Web Socket] Web socket connection is open");
				isRegistrationCompleted = true;
				break;
			case AsyncMessageType.MESSAGE:
				this.clientMessage = clientMessage;
				break;
			default:
				logger.info("[Web Socket] Couldn't understand what the server said...");
				break;
		}
	}

	/**
	 * prepare a message and send to async
	 *
	 * @param type    : set type of message (0,2,1,3)
	 * @param message : content of message
	 */
	protected void sendMessage(byte type, String message) {
		MessageWrapperVO messageWrapperVO;
		messageWrapperVO = new MessageWrapperVO();
		messageWrapperVO.setType(type);
		messageWrapperVO.setContent(message);

		String messageWrapperVOString = JsonUtil.getJson(messageWrapperVO);
		sendStringMessage(messageWrapperVOString);

		logger.debug(MessageFormat.format("[Web Socket] Client sent message {0} : {1}",
				type,
				messageWrapperVOString));
	}

	/**
	 * send message to Async
	 *
	 * @param str : the string to send
	 */
	private void sendStringMessage(String str) {
		try {
			session.getRemote().sendString(str);
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * @param request
	 */
	protected void prepareMessageToCorrectFormatAndSend(String request) {
		JSONObject js = new JSONObject();
		js.put("peerName", queueName);
		js.put("content", request);
		js.put("ttl", "30000");
		sendMessage(AsyncMessageType.MESSAGE, js.toJSONString());
	}
}
