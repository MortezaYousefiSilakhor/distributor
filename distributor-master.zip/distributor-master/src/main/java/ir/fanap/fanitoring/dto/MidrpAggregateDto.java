package ir.fanap.fanitoring.dto;

public class MidrpAggregateDto {
    private String name;
    private int count;
    private Object firstValue;
    private Object lastValue;
    private Double minValue;
    private Double maxValue;
    private Double sumValue;
    private Double avgValue;

    public MidrpAggregateDto(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Object getFirstValue() {
        return firstValue;
    }

    public void setFirstValue(Object firstValue) {
        this.firstValue = firstValue;
    }

    public Object getLastValue() {
        return lastValue;
    }

    public void setLastValue(Object lastValue) {
        this.lastValue = lastValue;
    }

    public Double getMinValue() {
        return minValue;
    }

    public void setMinValue(Double minValue) {
        this.minValue = minValue;
    }

    public Double getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Double maxValue) {
        this.maxValue = maxValue;
    }

    public Double getSumValue() {
        return sumValue;
    }

    public void setSumValue(Double sumValue) {
        this.sumValue = sumValue;
    }

    public Double getAvgValue() {
        return avgValue;
    }

    public void setAvgValue(Double avgValue) {
        this.avgValue = avgValue;
    }

    @Override
    public String toString() {
        return "MidrpAggregateDto{" +
                "name='" + name + '\'' +
                ", count=" + count +
                ", firstValue=" + firstValue +
                ", lastValue=" + lastValue +
                ", minValue=" + minValue +
                ", maxValue=" + maxValue +
                ", sumValue=" + sumValue +
                ", avgValue=" + avgValue +
                '}';
    }
}
