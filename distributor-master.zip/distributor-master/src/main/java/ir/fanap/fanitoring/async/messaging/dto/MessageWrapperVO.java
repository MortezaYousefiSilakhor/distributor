/**
 * Copyright (c) 2015-2017 Fanap ICT Holding. All Rights Reserved.
 */

package ir.fanap.fanitoring.async.messaging.dto;

/**
 * @author h.mehrara on 1/28/2015.
 */
public class MessageWrapperVO {

	private byte type;
	private String content;
	private Long trackerId;

	public MessageWrapperVO(byte type) {
		this.type = type;
	}

	public MessageWrapperVO() {
	}

	public byte getType() {
		return type;
	}

	public void setType(byte type) {

		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getTrackerId() {
		return trackerId;
	}

	public void setTrackerId(Long trackerId) {
		this.trackerId = trackerId;
	}
}
