package ir.fanap.fanitoring.async.messaging;

import ir.fanap.fanitoring.async.messaging.dto.AsyncMessageType;
import ir.fanap.fanitoring.async.messaging.dto.MessageVO;
import ir.fanap.fanitoring.async.messaging.dto.MessageWrapperVO;
import ir.fanap.fanitoring.async.util.JsonUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.concurrent.TimeUnit;

/**
 * Purpose of this class is to provide functions for sending a message/object into Async
 * This listener adds or removes MessageConsumer's clients and also delegates process on the received message into the desired class
 * <p>
 *
 * @author Alieh Mohtashami on 12/24/17.
 * @author Alireza Abedini on 5/21/20
 */

public class ActiveMQClientSender extends ActiveMQClient implements JMSClientSender {
	private static Logger logger = LogManager.getLogger(ActiveMQClientSender.class);
	private long defaultTtl = TimeUnit.SECONDS.toMillis(30);

	private ActiveMQClientSender(ActiveMQConnectionConfig activeMQConnectionConfig) {
		super(activeMQConnectionConfig);
	}

	public void connectToActiveMQ() throws JMSException, InterruptedException {
		openConnection(false, true);
	}

	public void sendMessageWithTrackerId(String object, long trackerId) throws UnsupportedEncodingException, JMSException {
		MessageVO messageVO = new MessageVO();
		messageVO.setTtl(defaultTtl);
		messageVO.setContent(object);
		MessageWrapperVO messageWrapperVO = new MessageWrapperVO();
		messageWrapperVO.setType(AsyncMessageType.MESSAGE);
		messageWrapperVO.setTrackerId(trackerId);
		messageWrapperVO.setContent(JsonUtil.getJson(messageVO));
		sendMessage(messageWrapperVO);
	}

	/**
	 * send message to q
	 *
	 * @param messageWrapperVO message to send
	 */
	public void sendMessage(MessageWrapperVO messageWrapperVO) throws UnsupportedEncodingException, JMSException {
		logger.debug(MessageFormat.format("[ActiveMQ Client Sender] Trying to send message: {0}", messageWrapperVO.getContent()));
		String json = JsonUtil.getJson(messageWrapperVO);
		byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
		BytesMessage bytesMessage = getSession().createBytesMessage();
		bytesMessage.writeBytes(bytes);
		getProducer().send(bytesMessage);
		logger.debug(MessageFormat.format("[ActiveMQ Client Sender] Message was ent to {0}", getProducer().getDestination()));
	}

	/**
	 * @param object  the message to send
	 * @param clients receivers of message
	 * @param <T>     Object type(Entity , String, command)
	 */
	public <T> void sendMessageToDefinedClients(T object, Long... clients) throws UnsupportedEncodingException, JMSException {
		MessageVO messageVO = new MessageVO();
		messageVO.setReceivers(clients);
		messageVO.setTtl(defaultTtl);
		setContentOfMessageVO(messageVO, object);
		MessageWrapperVO messageWrapperVO = new MessageWrapperVO();
		messageWrapperVO.setType(AsyncMessageType.MESSAGE);
		messageWrapperVO.setContent(JsonUtil.getJson(messageVO));
		sendMessage(messageWrapperVO);
		logger.debug(MessageFormat.format("[ActiveMQ Client Sender] A message was sent to {0} client(s): {1}",
				clients.length,
				messageWrapperVO));
	}

	/**
	 * set content for messageVo
	 *
	 * @param messageVO
	 * @param object    object to send
	 */
	private void setContentOfMessageVO(MessageVO messageVO, Object object) {
		messageVO.setContent(JsonUtil.getJson(object));
	}

	public void sendMessageToDefinedClients(String objectStr, Long... clients) throws UnsupportedEncodingException, JMSException {
		MessageVO messageVO = new MessageVO();
		messageVO.setReceivers(clients);
		messageVO.setTtl(defaultTtl);
		messageVO.setContent(objectStr);
		MessageWrapperVO messageWrapperVO = new MessageWrapperVO();
		messageWrapperVO.setType(AsyncMessageType.MESSAGE);
		messageWrapperVO.setContent(JsonUtil.getJson(messageVO));
		sendMessage(messageWrapperVO);
		logger.debug(MessageFormat.format("[ActiveMQ Client Sender] A message was sent to {0} client(s): {1}",
				clients.length,
				messageWrapperVO));
	}

	public static class BuilderAMQSender {
		ActiveMQConnectionConfig activeMQConnectionConfig;

		public BuilderAMQSender withActiveMQConnectionConfig(ActiveMQConnectionConfig activemqConnectionConfig) {
			this.activeMQConnectionConfig = activemqConnectionConfig;
			return this;
		}

		public ActiveMQClientSender build() throws IllegalArgumentException {
			if (activeMQConnectionConfig == null) {
				throw new IllegalArgumentException("Activemq Connection Config should not be null");
			}
			return new ActiveMQClientSender(activeMQConnectionConfig);
		}
	}

}
