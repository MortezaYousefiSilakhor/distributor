/**
 * Copyright (c) 2015-2017 Fanap ICT Holding. All Rights Reserved.
 */

package ir.fanap.fanitoring.async.messaging.dto;

/**
 * @author h.mehrara on 1/28/2015.
 */
public class MessageVO {
	private String peerName;
	private Long[] receivers;
	private long messageId;
	private long ttl = 30 * 1000;// TTL of message 1 minutes
	private String content; //RestResponse in json format in restOverAsync mode.

	public String getPeerName() {
		return peerName;
	}

	public void setPeerName(String peerName) {
		this.peerName = peerName;
	}

	public Long[] getReceivers() {
		return receivers;
	}

	public void setReceivers(Long[] receivers) {
		this.receivers = receivers;
	}

	public long getMessageId() {
		return messageId;
	}

	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}

	public long getTtl() {
		return ttl;
	}

	public void setTtl(long ttl) {
		this.ttl = ttl;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
