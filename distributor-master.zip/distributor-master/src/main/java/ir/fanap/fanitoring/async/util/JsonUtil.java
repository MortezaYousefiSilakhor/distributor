package ir.fanap.fanitoring.async.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.deser.std.FromStringDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.*;

/**
 * @author h.mehrara on 1/28/2015.
 * @author Alireza Abedini
 */
public class JsonUtil {
	protected final static Logger logger = LogManager.getLogger(JsonUtil.class);
	static final ObjectMapper mapper = new ObjectMapper();

	static {
		SimpleModule module = new SimpleModule();
		module.addSerializer(BigDecimal.class, new ToStringSerializer());
		module.addDeserializer(BigDecimal.class, new FromStringDeserializer<BigDecimal>(BigDecimal.class) {
			@Override
			protected BigDecimal _deserialize(String s, DeserializationContext deserializationContext) throws IOException {
				return new BigDecimal(s);
			}
		});
		mapper.registerModule(module);
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	}

	public static String getJson(Object obj) {
		try {
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			mapper.writeValue(bout, obj);
			byte[] objectBytes = bout.toByteArray();
			return new String(objectBytes);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	public static String getJson(List<Object> objects) {
		return new Gson().toJson(objects );

	}

	public static Object getValueFromJson(String key, String json) {
		JSONObject jsonObject;
		jsonObject = new JSONObject(json);
		if (!key.contains(".")) {
			return jsonObject.get(key);
		} else {
			String newKey = key.substring(key.indexOf('.') + 1);
			String ObjectKey = key.substring(0, key.indexOf('.'));
			String newJson = jsonObject.get(ObjectKey).toString();
			return getValueFromJson(newKey, newJson);
		}
	}

	public static <T> boolean isInstanceOfClass(String json, Class<T> classOfT) {
		try {
			mapper.readValue(json, classOfT);
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	public static <T> T getObject(byte[] json, Class<T> classOfT) {
		try {
			return mapper.readValue(new String(json, StandardCharsets.UTF_8), classOfT);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> T getObject(String json, Class<T> classOfT) {
		try {
			return mapper.readValue(json, classOfT);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> T getObject(String json, TypeReference<T> typeReference) {
		try {
			return mapper.readValue(json, typeReference);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static JSONObject getJsonObject(String json) {
		try {
			return new JSONObject(json);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static JSONArray getJsonArray(String json) {
		try {
			return new JSONArray(json);
		} catch (JSONException e) {
			throw new JSONException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Deprecated
	public static String getStringValueFromObject(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String string;
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		string = mapper.writeValueAsString(object);
		return string;
	}

	public static String showJson(String jsonString) {
		JSONObject jsonObject = new JSONObject(jsonString);
		List<String> result = new ArrayList<>();
		jsonObject.keys().forEachRemaining(key -> {
			Object object = jsonObject.get(key);
			result.add(MessageFormat.format("{0}:{1}", key, object));
		});
		String resultString = "";
		for (String row : result) {
			resultString += row + "\n";
		}
		return resultString;
	}

	public static String[] show2JsonDifference(String originalDtoJsonString, String afterOperationJsonString) {
		JSONObject afterOperationJson = new JSONObject(afterOperationJsonString);
		JSONObject originalDtoJson = new JSONObject(originalDtoJsonString);
		Set<String> keySet = new HashSet<String>();
		List<String> signDifferenceStringList = new ArrayList<>();
		List<String> justDifferenceStringList = new ArrayList<>();
		afterOperationJson.keys().forEachRemaining(key -> {
			Object afterValue = afterOperationJson.get(key);
			keySet.add(key);
			try {
				Object originalValue = originalDtoJson.get(key);
				if (originalValue.toString().equals(afterValue.toString())) {
					signDifferenceStringList.add(MessageFormat.format("{0}  :{1} -> {2}", key, originalValue, afterValue));
				} else {
					signDifferenceStringList.add(MessageFormat.format("** {0}  :{1} -> {2} **", key, originalValue, afterValue));
					justDifferenceStringList.add(MessageFormat.format("{0}  :{1} -> {2}", key, originalValue, afterValue));

				}
			} catch (Exception e) {
				//TODO	afterOperationJson has key that originalDtoJson dose not have.
				logger.error(MessageFormat.format("originalDtoJson in show2JsonDifference should have a {0} key, but doesn't", key));
			}
		});
		originalDtoJson.keys().forEachRemaining(key -> {
			if (!keySet.contains(key)) {
				Object orginalValue = originalDtoJson.get(key);
				//TODO	originalDtoJson  has key that afterOperationJson dose not have.
				logger.error(MessageFormat.format("afterOperationJson in show2JsonDifference should have a {0} key, but doesn't", key));

			}
		});
		String[] result = { "", "" };
		for (String row : signDifferenceStringList) {
			result[0] += row + "\n";
		}
		for (String row : justDifferenceStringList) {
			result[1] += row + "\n";
		}
		return result;
	}

	public static Object getIgnoreCase(JSONObject jobj, String key) {
		Iterator<String> iter = jobj.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			if (key1.equalsIgnoreCase(key)) {
				return jobj.get(key1);
			}
		}
		return null;
	}

	public static boolean hasIgnoreCase(JSONObject jsonObject, String key) {
		Iterator<String> iter = jsonObject.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			if (key1.equalsIgnoreCase(key)) {
				return true;
			}
		}
		return false;
	}

	public static Object matchWithJsonPattern(JSONObject jsonObject, String key) {
		try {
			Iterator<String> iter = jsonObject.keySet().iterator();
			while (iter.hasNext()) {
				String pattern = iter.next();
				if (key.matches(pattern)) {
					return jsonObject.get(pattern);
				}
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}
}
