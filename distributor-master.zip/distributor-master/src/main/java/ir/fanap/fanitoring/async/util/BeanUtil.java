package ir.fanap.fanitoring.async.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component(value = "beanUtil")
public class BeanUtil implements ApplicationContextAware {

	private static ApplicationContext context;

	public static <T> T getBean(Class<T> beanClass) {
		try {
			return context.getBean(beanClass);
		} catch (Exception e) {
			return null;
		}
	}

	public static <T> T getBean(Class<T> beanClass, Object... objects) {
		return context.getBean(beanClass, objects);
	}

	public static String getProperty(String name) {
		return ((Properties) context.getBean("properties")).getProperty(name);
	}

	public ApplicationContext getApplicationContext() {
		return context;
	}

	@Override
	public void setApplicationContext(ApplicationContext ac) throws BeansException {
		context = ac;
	}
}
