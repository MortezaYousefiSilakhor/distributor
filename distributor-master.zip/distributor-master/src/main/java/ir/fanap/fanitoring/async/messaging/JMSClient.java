package ir.fanap.fanitoring.async.messaging;

import javax.jms.JMSException;

/**
 * @author Alieh Mohtashami on 12/24/17.
 * Interface for a JmsClient
 * always have clients to messaging and some initial properties
 */
public interface JMSClient {

	/**
	 * create a connection between to JmsClient
	 *
	 * @param isConsumerNeeded a boolean parameter to configuration output queue
	 * @param isProducerNeeded a boolean parameter to configuration input queue
	 */
	boolean openConnection(boolean isConsumerNeeded, boolean isProducerNeeded) throws Exception;

	/**
	 * close the connection
	 *
	 * @param isForced
	 * @throws JMSException
	 */
	void closeConnection(boolean isForced) throws JMSException;

}
