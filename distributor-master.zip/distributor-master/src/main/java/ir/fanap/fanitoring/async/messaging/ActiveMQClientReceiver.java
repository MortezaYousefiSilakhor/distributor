package ir.fanap.fanitoring.async.messaging;

import ir.fanap.fanitoring.async.messaging.dto.AsyncMessageType;
import ir.fanap.fanitoring.async.messaging.dto.ClientMessage;
import ir.fanap.fanitoring.async.messaging.dto.RequestProcessor;
import ir.fanap.fanitoring.async.util.JsonUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.concurrent.BlockingQueue;

/**
 * Purpose of this class is to provide listener thread on MessageConsumer
 * This listener do one of these two works: adds or removes MessageConsumer's clients
 * or put message to blockingQ and pass it to appropriate class
 * <p>
 *
 * @author Alieh Mohtashami on 12/24/17.
 * @author Alireza Abedini
 */

public class ActiveMQClientReceiver extends ActiveMQClient implements JMSClientReceiver, Runnable {
	private Logger logger = LogManager.getLogger(ActiveMQClientSender.class);
	private BlockingQueue<ClientMessage> blockingQueue;
	private RequestProcessor requestProcessor;
	private String name;
	private boolean keepLiving = true;

	private ActiveMQClientReceiver(String name, ActiveMQConnectionConfig activeMQConnectionConfig, BlockingQueue blockingQueue, RequestProcessor requestProcessor) {
		super(activeMQConnectionConfig);
		this.blockingQueue = blockingQueue;
		this.requestProcessor = requestProcessor;
		this.name = name;
	}

	public void stop() {
		keepLiving = false;
		try {
			getConsumer().close();
		} catch (JMSException e) {
			logger.error(MessageFormat.format("{0} An error occurred in stop method: {1}", name, e.getMessage()));
		}
	}

	/**
	 * Initializes and runs a thread whose job is listening on MessageConsumer
	 */
	@Override
	public void run() {
		try {
			openConnection(true, false);
			while (keepLiving) {
				try {
					if (Thread.currentThread().isInterrupted()) {
						logger.error(MessageFormat.format("{0} was interrupted and stopped", name));
						break;
					}
					logger.debug(MessageFormat.format("{0} is waiting for message", name));
					Message message = getConsumer().receive();
					if (message instanceof BytesMessage) {
						BytesMessage bytesMessage = (BytesMessage) message;
						byte[] buffer = new byte[(int) bytesMessage.getBodyLength()];
						int readBytes = bytesMessage.readBytes(buffer);
						if (readBytes != bytesMessage.getBodyLength()) {
							logger.fatal(MessageFormat.format("{0} Inconsistent message length", name));
						}

						String json = new String(buffer, StandardCharsets.UTF_8);
						logger.debug(MessageFormat.format("{0} A new message received ({1})", name, json));
						ClientMessage clientMessage = JsonUtil.getObject(json, ClientMessage.class);
						processMessage(clientMessage);
					}
				} catch (JMSException e) {//network problem
					logger.error(MessageFormat.format("{0} Error in create connection to activemq, try to reconnect ", name));
					openConnection(true, false);
				} catch (UnsupportedEncodingException e) {//error in encoding
					logger.fatal(MessageFormat.format("{0}: Error in message encoding: {1}", name, e.getMessage()));
				}
			}
			logger.info(MessageFormat.format("{0} was stopped", name));
		} catch (Exception e) {
			logger.fatal(name + e.getMessage());
			Thread.currentThread().interrupt();
		}
	}

	@Override
	public void processMessage(ClientMessage clientMessage) throws Exception {
		if (clientMessage.getType() == AsyncMessageType.MESSAGE) {
			if (requestProcessor != null) {
				requestProcessor.addItem(clientMessage);
			} else {
				try {
					if (blockingQueue != null) {
						blockingQueue.put(clientMessage);
					}
				} catch (InterruptedException e) {
					throw new Exception(MessageFormat.format("Ignorable exception on blockingQ {0}", name));
				}
			}
		}
	}

	public static class AMQReceiverBuilder {
		Logger logger;
		ActiveMQConnectionConfig activemqConnectionConfig;
		private BlockingQueue<ClientMessage> blockingQueue;
		private RequestProcessor requestProcessor;
		private String name;

		public AMQReceiverBuilder withName(String name) {
			this.name = name;
			return this;
		}

		public AMQReceiverBuilder withLogger(Logger logger) {
			this.logger = logger;
			return this;
		}

		public AMQReceiverBuilder withActiveMQClient(ActiveMQConnectionConfig activemqConnectionConfig) {
			this.activemqConnectionConfig = activemqConnectionConfig;
			return this;
		}

		@Deprecated
		public AMQReceiverBuilder withBlockingQ(BlockingQueue blockingQ) {
			this.blockingQueue = blockingQ;
			return this;
		}

		public AMQReceiverBuilder withRequestList(RequestProcessor requestProcessor) {
			this.requestProcessor = requestProcessor;
			return this;
		}

		public ActiveMQClientReceiver build() throws Exception {
			if (name == null) {
				throw new Exception("name should not be null");
			}

			if (activemqConnectionConfig == null) {
				throw new Exception("activemqConnectionConfig should not be null");
			}
			// there should be a blockingQ or list to store data
			if (blockingQueue == null && requestProcessor == null) {
				throw new Exception("blockingQ is null. message from a server should be put in blockingQ");
			}
			return new ActiveMQClientReceiver(name, activemqConnectionConfig, blockingQueue, requestProcessor);
		}
	}
}
