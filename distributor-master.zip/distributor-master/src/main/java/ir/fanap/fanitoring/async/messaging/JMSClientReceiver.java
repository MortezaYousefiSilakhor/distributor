package ir.fanap.fanitoring.async.messaging;

import ir.fanap.fanitoring.async.messaging.dto.ClientMessage;

/**
 * @author alieh on 12/24/17.
 */
public interface JMSClientReceiver extends JMSClient {

	/**
	 * process the message received from client by server
	 *
	 * @param clientMessage message received
	 * @throws Exception when cannot get client list
	 */
	void processMessage(ClientMessage clientMessage) throws Exception;

}
