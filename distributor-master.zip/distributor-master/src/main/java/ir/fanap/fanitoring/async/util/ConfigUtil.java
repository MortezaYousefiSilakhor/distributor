package ir.fanap.fanitoring.async.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.Cipher;
import java.io.*;
import java.net.ConnectException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class ConfigUtil {
	private final static String TEMP_DIR = System.getProperty("java.io.tmpdir");
	private final static String DECRYPTED_CONFIG_PROPERTIES = "decrypted-config.properties";
	private final static String GENERATED_CONFIG_PROPERTIES = "generated-config.properties";
	private final static String MODULE_CONFIG_PROPERTIES = "default-config.properties";
	private final static String CONFIG_URL_KEY = "config.url";
	private final static String REQUIRED_KEYS_LIST = "required.keys";
	private final static String IS_CONFIG_ENCRYPTED = "is.config.encrypted";
	private final static Logger logger = LogManager.getLogger(ConfigUtil.class);

	public static boolean makeConfigFile(Class clazz) {
		logger.info("[General Config Manager] Trying to read configs ...");
		Properties prop = new Properties();
		// Make sure that the configuration file exists
		logger.info("[General Config Manager] Check default config file");
		URL specialConfigUrl = Objects.requireNonNull(
				clazz.getClassLoader().getResource(MODULE_CONFIG_PROPERTIES), ". Can't find configuration file app.config");
		logger.info("[General Config Manager] Default config file is available");

		logger.info("[General Config Manager] Loading the properties ...");
		try (InputStream specialInputStream = specialConfigUrl.openStream()) {
			prop.load(specialInputStream);
			String commonConfigLocation = prop.getProperty(CONFIG_URL_KEY);
			String[] neededKeys = prop.getProperty(REQUIRED_KEYS_LIST).split(",");
			boolean readConfigFromEncryptedFile = Boolean.valueOf(prop.getProperty(IS_CONFIG_ENCRYPTED, "true"));
			try {
				Properties generalProp = new Properties();
				if (readConfigFromEncryptedFile) {
					decryptGeneralConfig(commonConfigLocation);
					generalProp.load(new FileInputStream(TEMP_DIR + "/" + DECRYPTED_CONFIG_PROPERTIES));
				} else {
					loadGeneralProperties(commonConfigLocation, generalProp);
				}
				try {
					BufferedWriter out = new BufferedWriter(new FileWriter(clazz.getClassLoader().getResource(GENERATED_CONFIG_PROPERTIES).getFile(), false));
					String version = prop.getProperty("version");
					logger.info("Version of " + clazz.getSimpleName() + " is " + version);
					for (int i = 0; i < neededKeys.length; ++i) {
						neededKeys[i] = neededKeys[i].trim();
						if (!generalProp.containsKey(neededKeys[i])) {
							logger.error(MessageFormat.format("[General Config Manager] Key {0} not found, check the key or encryption/decryption mode", neededKeys[i]));
							return false;
						}
						out.write(neededKeys[i] + "=" + generalProp.getProperty(neededKeys[i].trim()) + "\n");
					}
					out.close();
				} catch (IOException e) {
					logger.error("[General Config Manager] Error in writing to " + GENERATED_CONFIG_PROPERTIES);
					return false;
				}
			} catch (Exception e) {
				logger.error(MessageFormat.format("[General Config Manager] {0} not found", commonConfigLocation));
				return false;
			}
		} catch (IOException e) {
			logger.error(MessageFormat.format("[General Config Manager] Error in loading properties file{0}", e.getMessage()));
			return false;
		} finally {
			FileUtil.deleteFile(TEMP_DIR + "/" + DECRYPTED_CONFIG_PROPERTIES);
		}
		logger.info("[General Config Manager] Config file was filled successfully");
		return true;
	}

	/**
	 * this method get encrypted content from uri,
	 * it copy the content to a local file, then decrypt file and finally save the decrypted file	 *
	 *
	 * @param uri path of encrypted file
	 * @throws Exception IO exception
	 */
	private static void decryptGeneralConfig(String uri) throws IOException {
		String tmpEncryptedConfigFile = TEMP_DIR + "/encrypted-config.properties";
		String tmpDecryptedConfigFile = TEMP_DIR + "/" + DECRYPTED_CONFIG_PROPERTIES;
		try (BufferedInputStream inputStream = new BufferedInputStream(new URL(uri).openStream());
			 FileOutputStream fileOS = new FileOutputStream(tmpEncryptedConfigFile)) {
			byte[] data = new byte[1024];
			int byteContent;
			while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
				fileOS.write(data, 0, byteContent);
			}
			CryptoUtil.fileProcessor(Cipher.DECRYPT_MODE, new File(tmpEncryptedConfigFile), new File(tmpDecryptedConfigFile));
		}
	}

	private static void loadGeneralProperties(String commonConfigLocation, Properties generalProp) throws IOException, InterruptedException {
		boolean isConfigLoaded = false;
		logger.info("[General Config Manager] Loading properties from general config ...");
		while (!isConfigLoaded) {
			try {
				URL configUrl = new URL(commonConfigLocation);
				InputStream generalInputStream = configUrl.openStream();
				generalProp.load(generalInputStream);
				isConfigLoaded = true;
			} catch (ConnectException e) {
				logger.error(MessageFormat.format("[General Config Manager] Connection refused to General Config Host: {0}", commonConfigLocation));
				logger.info("[General Config Manager] Waiting for 15 seconds and retry");
				Thread.sleep(TimeUnit.SECONDS.toMillis(15));
			}
		}
		logger.info("[General Config Manager] Properties was loaded successfully from general config");
	}

	public static String loadProperty(String propertyName) throws IOException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream(GENERATED_CONFIG_PROPERTIES);
		Properties properties = new Properties();
		properties.load(input);
		return properties.getProperty(propertyName);
	}

}
