package ir.fanap.fanitoring.async.messaging.dto;

/**
 * @author test on 5/29/2016.
 */
public class PeerMessage {
	private String deviceId;
	private String appId;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}
}
