package ir.fanap.fanitoring.async.messaging.dto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.MessageFormat;
import java.util.concurrent.BlockingQueue;

/**
 * @author Alireza Abedini on 7/27/19
 */
public abstract class InternalQueueConsumer<T> implements Runnable {
	private Logger logger = LogManager.getLogger(InternalQueueConsumer.class);
	private BlockingQueue<T> blockingQueue;
	private String name;

	public InternalQueueConsumer(BlockingQueue<T> blockingQueue, String name) {
		this.blockingQueue = blockingQueue;
		this.name = name;
	}

	@Override
	public void run() {
		logger.info(MessageFormat.format("Consumer of Queue <{0}> is running", name));
		while (true) {
			try {
				T item = blockingQueue.take();
				process(item);
			} catch (InterruptedException ignored) {
				logger.warn("An exception occurred when take an item from queue: " + ignored.getMessage());
			}
		}
	}

	public abstract void process(T item) throws InterruptedException;
}
