package ir.fanap.fanitoring.redis;

import ir.fanap.fanitoring.mqtt.MQTTPublisher;
import ir.fanap.fanitoring.queue.ActiveMqSender;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Service;

@Service
public class RedisSubscriber implements MessageListener {

    private static final Logger logger = LogManager.getLogger(RedisSubscriber.class);

    @Value("${mqttSender.enabled}")
    private boolean mqttSender;

    @Value("${midrpSender.enabled}")
    private boolean midrpSender;

    private MQTTPublisher mqttPublisher;

    public RedisSubscriber(MQTTPublisher mqttPublisher) {
        this.mqttPublisher = mqttPublisher;
    }

    @Autowired
    private ActiveMqSender activeMqSender;

    @Override
    public void onMessage(Message message, byte[] bytes) {
        String strMessage = message.toString();
        try {
            strMessage = strMessage.substring(strMessage.indexOf('{'), strMessage.length());
        } catch (Exception e) {
            logger.error("Subscribe message has the wrong format.Jason format must be observed");
        }
        if (mqttSender)
            mqttPublisher.publish(strMessage);
        if (midrpSender)
            activeMqSender.extractJsonMessage(strMessage);

    }
}