package ir.fanap.fanitoring.async.messaging;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.websocket.client.ClientUpgradeRequest;
import org.eclipse.jetty.websocket.client.WebSocketClient;

import java.net.URI;
import java.text.MessageFormat;

/**
 * @author Mohsen Ebrahimi on 5/17/17.
 * Edited by Alieh Mohtashami to catch exceptions and repositioning
 * this class is create a websocket to a url
 */
public class WebSocketClientWrapper {
	private AsyncSocket socket;
	private Logger logger = LogManager.getLogger(WebSocketClientWrapper.class);
	private WebSocketClient client = new WebSocketClient();
	private String webSocketUrl;

	public WebSocketClientWrapper(AsyncSocket socket, Logger logger, String webSocketUrl) {
		this.socket = socket;
		this.logger = logger;
		socket.setLogger(logger);
		this.webSocketUrl = webSocketUrl;
	}

	public void connect() throws Exception {
		logger.info(MessageFormat.format("[Web Socket Client Wrapper] Trying to connect to {0}", webSocketUrl));
		client.start();
		URI echoUri = new URI(webSocketUrl);
		ClientUpgradeRequest request = new ClientUpgradeRequest();
		try {
			client.connect(socket, echoUri, request);
		} catch (Exception e) {
			logger.error(MessageFormat.format("[Web Socket Client Wrapper] An error occurred when open connection to {0}", webSocketUrl));
			client.stop();
			throw e;
		}
		logger.info(MessageFormat.format("[Web Socket Client Wrapper] Client was connected to {0} successfully", webSocketUrl));
	}

	public void stop() throws Exception {
		if (!client.isStopped()) {
			client.stop();
		}
	}
}
