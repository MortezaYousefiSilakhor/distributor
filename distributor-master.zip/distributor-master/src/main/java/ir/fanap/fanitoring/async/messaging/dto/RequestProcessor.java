package ir.fanap.fanitoring.async.messaging.dto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.jms.JMSException;
import java.text.MessageFormat;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author Alieh Mohtashami
 * This class have an internal q which fill from outside
 * here we want to use it as an interface for sending data to activemq or saving data to database
 */
public abstract class RequestProcessor {
	private Logger logger = LogManager.getLogger(RequestProcessor.class);
	private BlockingQueue<Object> blockingQueue = new LinkedBlockingQueue<>();
	private ExecutorService executorService;
	private String name;

	public RequestProcessor(String name) {
		this(name, 1);
	}

	public RequestProcessor(String name, int numberOfExecutors) {
		this.name = name;
		logger.info(MessageFormat.format("{0} Creating request list with {1} executor",
				name,
				numberOfExecutors));
		executorService = Executors.newFixedThreadPool(numberOfExecutors);
	}

	/**
	 * @param object the item which should be added to queue,
	 */
	public void addItem(Object object) {
		blockingQueue.add(object);
		executorService.execute(getConsumer());
		logger.debug(MessageFormat.format("{0} A new item is added to list, there are {1} items in queue",
				name,
				blockingQueue.size()));
	}

	private Runnable getConsumer() {
		Runnable taskConsumer = (() -> {
			Object object;
			try {
				object = blockingQueue.take();
				processItem(object);
			} catch (InterruptedException e) {
				logger.error(MessageFormat.format("{0} Consumer was interrupted: {1}",
						name,
						e.getMessage()));
			}
		});
		return taskConsumer;
	}

	/**
	 * This method is to implement what we want to do with an item
	 */
	public abstract void processItem(Object object);

	/**
	 * this method should be called after construction, it starts thread after connection to target (if needed)
	 */
	@PostConstruct
	private void postConstruct() throws JMSException, InterruptedException {
		initProducer();
	}

	/**
	 * initial producer (if needed)
	 */
	public void initProducer() throws InterruptedException, JMSException {
	}

	@PreDestroy
	public void destroyBean() {
		logger.info(MessageFormat.format("{0} Trying to destroy with {1} item(s) in queue ...",
				name,
				blockingQueue.size()));
		Long begin = System.currentTimeMillis();
		while (!blockingQueue.isEmpty() && isInDeadLine(begin)) {
			if (logger.isDebugEnabled()) {
				logger.debug(MessageFormat.format("\r{0} Number of items in queue = {1}",
						name,
						blockingQueue.size()));
			}
		}
		executorService.shutdown();
		logger.info(MessageFormat.format("{0} Destroyed successfully", name));
	}
	public boolean isInDeadLine(Long begin){
		Long threshold = 1 * 60 * 1000l;//One minute
		return System.currentTimeMillis() < begin + threshold;
	}

	public BlockingQueue<Object> getBlockingQueue() {
		return blockingQueue;
	}
}
