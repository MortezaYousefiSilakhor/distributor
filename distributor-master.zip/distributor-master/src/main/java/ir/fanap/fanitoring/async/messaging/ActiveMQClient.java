package ir.fanap.fanitoring.async.messaging;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.qpid.amqp_1_0.jms.impl.QueueImpl;

import javax.jms.*;
import java.text.MessageFormat;

/**
 * @author Alieh Mohtashami on 12/24/17.
 * @author Alireza Abedini
 */
public class ActiveMQClient implements JMSClient {
	private static final Logger logger = LogManager.getLogger(ActiveMQClient.class);
	private static int tryNumber = 720 * 12;
	private static long millisecondToWait = 5000;
	private static long timeToLive;
	protected Connection connection;
	protected MessageProducer producer;
	protected MessageConsumer consumer;
	protected Session session;
	protected ActiveMQConnectionConfig activeMQConnectionConfig;
	private boolean isConsumerNeeded;
	private boolean isProducerNeeded;

	/**
	 * @param activeMQConnectionConfig activemq connection information
	 */
	public ActiveMQClient(ActiveMQConnectionConfig activeMQConnectionConfig) {
		setActiveMQClientEntity(activeMQConnectionConfig);
	}

	private void setActiveMQClientEntity(ActiveMQConnectionConfig activeMQConnectionConfig) {
		this.activeMQConnectionConfig = activeMQConnectionConfig;
	}

	public MessageProducer getProducer() {
		return producer;
	}

	public MessageConsumer getConsumer() {
		return consumer;
	}

	public Session getSession() {
		if (((ActiveMQSession) session).isClosed()) {
			try {
				session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			} catch (JMSException retry) {
				try {
					logger.error(MessageFormat.format("[ActiveMQ Client] session is closed, try to open new connection. (ERROR: {0})", retry.getMessage()));
					openConnection(isConsumerNeeded, isProducerNeeded, 1);
				} catch (InterruptedException | JMSException ignored) {
					logger.error(MessageFormat.format("[ActiveMQ Client] session is closed and we can not create new session. (ERROR {0})", ignored.getMessage()));
				}
			}
		}
		return session;
	}

	/**
	 * this method tries to connect to activemq by limited number of times
	 *
	 * @param isConsumerNeeded a boolean parameter to configuration input queue
	 * @param isProducerNeeded a boolean parameter to configuration output queue
	 * @return true if connection is established, false otherwise
	 */
	private boolean openConnection(boolean isConsumerNeeded, boolean isProducerNeeded, int numberOfRetries) throws InterruptedException, JMSException {
		this.isConsumerNeeded = isConsumerNeeded;
		this.isProducerNeeded = isProducerNeeded;
		logger.info(MessageFormat.format("[ActiveMQ Client] Try to connect to:" +
						"\n\tURL: {0}" +
						"\n\tInput Queue: {1}" +
						"\n\tOutput Queue: {2}",
				this.activeMQConnectionConfig.getActiveMQUrl(),
				this.activeMQConnectionConfig.getInputUrl(),
				this.activeMQConnectionConfig.getOutputUrl()));
		if (!isConsumerNeeded && !isProducerNeeded) {
			throw new IllegalArgumentException("[ActiveMQ Client] Error on opening activemq connection, at least one consumer or producer is needed");
		}
		closeConnection(false);
		int counter = numberOfRetries;
		while (counter >= 0) {
			try {
				if (Thread.currentThread().isInterrupted()) {
					throw new InterruptedException(MessageFormat.format("[ActiveMQ Client] Thread {0} is terminated", Thread.currentThread().getName()));
				}
				ActiveMQConnectionConfig activeMQConnectionConfig = this.activeMQConnectionConfig;
				ActiveMQConnectionFactory factory =
						new ActiveMQConnectionFactory(activeMQConnectionConfig.getUsername(), activeMQConnectionConfig.getPassword(), activeMQConnectionConfig.getActiveMQUrl());
				connection = factory.createConnection(activeMQConnectionConfig.getUsername(), activeMQConnectionConfig.getPassword());
				logger.info("[ActiveMQ Client] Trying to start connection ...");
				connection.start();
				logger.info("[ActiveMQ Client] connection started successfully.");
				logger.info("[ActiveMQ Client] Trying to create a session ...");
				session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
				logger.info("[ActiveMQ Client] Session created successfully.");

				if (isProducerNeeded) {
					Destination outputQueue = new QueueImpl(activeMQConnectionConfig.getOutputUrl());
					producer = session.createProducer(outputQueue);
					producer.setTimeToLive(timeToLive);
					logger.info("[ActiveMQ Client] Producer was created successfully");
				}

				if (isConsumerNeeded) {
					Destination inputQueue = new QueueImpl(activeMQConnectionConfig.getInputUrl());
					consumer = session.createConsumer(inputQueue);
					logger.info("[ActiveMQ Client] Consumer was created successfully");
				}
				logger.info("[ActiveMQ Client] successfully connected to activemq");
				break;
			} catch (JMSException e) {
				try {
					counter--;
					if (counter == 0) {
						throw new JMSException(e.getMessage());
					} else {
						logger.error(MessageFormat.format("[ActiveMQ Client] cannot connect to activemq because of {0} ({1} tries are remained)",
								e.getMessage(),
								counter));
					}
					Thread.sleep(millisecondToWait);
				} catch (InterruptedException e1) {
					throw new InterruptedException(MessageFormat.format("[ActiveMQ Client] Thread {0} is interrupted when retry to reconnect",
							Thread.currentThread().getName()));
				}
			}
		}
		return true;
	}

	public boolean openConnection(boolean isConsumerNeeded, boolean isProducerNeeded) throws InterruptedException, JMSException {
		return openConnection(isConsumerNeeded, isProducerNeeded, tryNumber);
	}

	public void closeConnection(boolean isForced) throws JMSException {
		//TODO: refactor these statements
		if (connection == null || isForced) {
			if (connection != null) {
				connection.close();
				connection = null;
			}
			if (session != null) {
				session.close();
				session = null;
			}
			if (producer != null) {
				producer.close();
				producer = null;
			}
			if (consumer != null) {
				consumer.close();
				consumer = null;
			}
		}

	}

	public void setTryNumber(int tryNumber) {
		ActiveMQClient.tryNumber = tryNumber;
	}

	public void setMillisecondToWait(long millisecondToWait) {
		ActiveMQClient.millisecondToWait = millisecondToWait;
	}

	public void setTimeToLive(long timeToLive) {
		ActiveMQClient.timeToLive = timeToLive;
	}
}
