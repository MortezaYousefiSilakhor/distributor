package ir.fanap.fanitoring.queue.sender;

import ir.fanap.fanitoring.async.messaging.ActiveMQClientSender;
import ir.fanap.fanitoring.async.messaging.ActiveMQConnectionConfig;
import ir.fanap.fanitoring.async.messaging.dto.RequestProcessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import java.text.MessageFormat;


@Service
@Lazy
public class MidrpOutputRequestProcessor extends RequestProcessor {

	private Logger logger = LogManager.getLogger(MidrpOutputRequestProcessor.class);
	@Autowired
	private ActiveMQConnectionConfig activeMQConnectionConfig;

	@Value("#{${midrp.peer.ids}}")
	private Long[] clients;

	private ActiveMQClientSender activeMQClientSender;

	public MidrpOutputRequestProcessor() {
		super("[Midrp Output Request Processor]");
	}

	@Override
	public void processItem(Object object) {
		try {
			logger.debug("[Midrp Output Request Processor] New request received");

				activeMQClientSender.sendMessageToDefinedClients(object, clients);
				logger.debug("[Midrp Output Request Processor] Value request processed and sent");

		} catch (Exception e) {
			logger.error(MessageFormat.format("[Midrp Output Request Processor] An error occurred when process item: {0}", e.getMessage()));
		}
	}

	@Override
	public void initProducer() throws InterruptedException, JMSException {
		logger.info("[Midrp Output Request Processor] Initial producer");
		this.activeMQClientSender = new ActiveMQClientSender
				.BuilderAMQSender()
				.withActiveMQConnectionConfig(activeMQConnectionConfig)
				.build();
		activeMQClientSender.connectToActiveMQ();
		logger.info(MessageFormat.format("[Midrp Output Request Processor] Producer was connected successfully:" +
						"\n\tURL: {0}" +
						"\n\tInput Queue: {1}" +
						"\n\tOutput Queue: {2}",
				this.activeMQConnectionConfig.getActiveMQUrl(),
				this.activeMQConnectionConfig.getInputUrl(),
				this.activeMQConnectionConfig.getOutputUrl()));
	}
}
