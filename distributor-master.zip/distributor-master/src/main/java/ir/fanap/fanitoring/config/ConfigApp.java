package ir.fanap.fanitoring.config;

import ir.fanap.fanitoring.async.messaging.ActiveMQConnectionConfig;
import ir.fanap.fanitoring.mqtt.MQTTPublisher;
import ir.fanap.fanitoring.redis.RedisSubscriber;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

import java.text.MessageFormat;

@Configuration
public class ConfigApp {

    private static final Logger logger = LogManager.getLogger(ConfigApp.class);

    @Value("${redis.topic}")
    private String redisTopic;

    @Value("${async.midrp.amqprovider.url}")
    String activeMQUrl;
    @Value("${async.midrp.amqprovider.username}")
    String username;
    @Value("${async.midrp.amqprovider.pass}")
    String password;
    @Value("${async.midrp.provider.producer}")
    String outputUrl;

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);
        return template;
    }

    @Bean
    MQTTPublisher mqttPublisher(){
        return new MQTTPublisher();
    }
    @Bean
    RedisSubscriber distributeRedisSubscriber(){
        return new RedisSubscriber(mqttPublisher());
    }
    @Bean
    MessageListenerAdapter messageListener() {
        return new MessageListenerAdapter(distributeRedisSubscriber());
    }


    @Bean
    RedisMessageListenerContainer redisContainer(RedisConnectionFactory connectionFactory) {
        RedisMessageListenerContainer container
                = new RedisMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.addMessageListener(messageListener(), topic());
        return container;
    }

    @Bean
    ChannelTopic topic() {
        return new ChannelTopic(redisTopic);
    }


    @Bean
    public ActiveMQConnectionConfig midrpActiveMQConnectionConfig() {
        ActiveMQConnectionConfig activeMQConnectionConfig = new ActiveMQConnectionConfig();
        activeMQConnectionConfig.setActiveMQUrl(activeMQUrl);
        activeMQConnectionConfig.setUsername(username);
        activeMQConnectionConfig.setPassword(password);
        activeMQConnectionConfig.setOutputUrl(outputUrl);
        logger.info("[RTM Config] ActiveMQ Connection Config was created successfully:" +
                        "\n\tURL: {0}" +
                        "\n\tOutput Queue: {2}",
                this.activeMQUrl,
                this.outputUrl);
        return activeMQConnectionConfig;
    }


}
