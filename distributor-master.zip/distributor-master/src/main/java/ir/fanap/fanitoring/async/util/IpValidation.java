package ir.fanap.fanitoring.async.util;

import java.util.Arrays;

/**
 * @author Alireza Abedini on 12/29/19
 */
public class IpValidation {
	/**
	 * Check that a string represents a decimal number
	 *
	 * @param string The string to check
	 * @return true if string consists of only numbers without leading zeroes, false otherwise
	 */
	private static boolean isDecimal(String string) {
		// Check whether string has a leading zero but is not "0"
		for (char c : string.toCharArray()) {
			if (c < '0' || c > '9') {
				return false;
			}
		}
		return true;
	}

	public static boolean isIp(String string) {
		String[] parts = string.split("\\.", -1);
		return parts.length == 4 // 4 parts
				&& Arrays.stream(parts)
				.filter(string1 -> isDecimal(string1)) // Only decimal numbers
				.map(Integer::parseInt)
				.filter(i -> i <= 255 && i >= 0) // Must be inside [0, 255]
				.count() == 4; // 4 numerical parts inside [0, 255]
	}

}