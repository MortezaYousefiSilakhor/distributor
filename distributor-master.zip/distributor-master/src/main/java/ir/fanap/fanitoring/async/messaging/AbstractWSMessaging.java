package ir.fanap.fanitoring.async.messaging;

import org.eclipse.jetty.websocket.api.annotations.WebSocket;

/**
 * this class in for handling websocket operation between client and server (queueName)
 * it override method onMessage to customize the communication (after registering to Async in parent class)
 * after registering every child class can has its own implementation for messaging by overriding feelFreeToChatWithServer
 */
@WebSocket(maxTextMessageSize = 1000 * 1024)
public abstract class AbstractWSMessaging extends AsyncSocket {
	protected String request = "first request";
	protected String reply = null;

	public AbstractWSMessaging(String queueName) {
		super(queueName);
	}

	/**
	 * This method is for customize communication
	 *
	 * @param receivedMsg the message received from server
	 *                    if registering is completed talking with server can begin
	 */
	@Override
	public void onMessage(String receivedMsg) {
		super.onMessage(receivedMsg);
		if (isRegistrationCompleted) {
			feelFreeToChatWithServer();
		}
	}

	/**
	 * This method is abstract to force every child class implement it after being registered to async
	 */
	protected abstract void feelFreeToChatWithServer();

	public void setRequest(String request) {
		this.request = request;
	}

	public String getReply() {
		return reply;
	}

}
