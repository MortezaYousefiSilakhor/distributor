package ir.fanap.fanitoring.queue;

import ir.fanap.fanitoring.dto.MidrpAggregateDto;
import ir.fanap.fanitoring.queue.sender.MidrpOutputRequestProcessor;
import ir.fanap.fanitoring.redis.RedisSubscriber;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;

@Service
@Configurable
public class ActiveMqSender extends TimerTask {

    private static final Logger logger = LogManager.getLogger(ActiveMqSender.class);

    @Value("${activeMq.sender.interval}")
    private Long period;

    private Map<String, MidrpAggregateDto> aggregateTagMap = new HashMap();

    @Autowired
    private MidrpOutputRequestProcessor midrpOutputRequestProcessor;

    @PostConstruct
    public void init() {
        Timer time = new Timer();
        time.schedule(this, 0, period);
    }

    public void run() {
        for (Map.Entry<String, MidrpAggregateDto> entry : aggregateTagMap.entrySet()) {
            try {
                if(entry.getValue().getCount()>0) {
                    midrpOutputRequestProcessor.addItem(entry.getValue());
                    logger.info("send " + entry.getValue());
                }
            } catch (Exception e) {
                logger.error("cant send message to active-mq");
            }
        }
        logger.info("-------------------------------------------------------------------");
        aggregateTagMap = new HashMap<>();
    }

    public void extractJsonMessage(String message) {
        try {
            String string = message.toString();
            string = string.substring(string.indexOf('{'), string.length());
            JSONObject jsonObject = new JSONObject(string);
            Iterator<String> keys = jsonObject.keys();
            String key;
            Object value;
            while (keys.hasNext()) {
                key = keys.next();
                value = jsonObject.get(key);
                if (value != null && !value.equals("Bad 255") && !value.equals("bad255 ")) {
                    MidrpAggregateDto MidrpObj = aggregateTagMap.get(key);
                    if (MidrpObj == null) {
                        MidrpObj = new MidrpAggregateDto();
                        MidrpObj.setCount(1);
                        MidrpObj.setFirstValue(value);
                        MidrpObj.setLastValue(value);
                        MidrpObj.setName(key);
                        if (value instanceof Number) {
                            Double doubleValue = new Double(value.toString());
                            MidrpObj.setAvgValue(doubleValue);
                            MidrpObj.setMinValue(doubleValue);
                            MidrpObj.setMaxValue(doubleValue);
                            MidrpObj.setSumValue(doubleValue);
                        }
                    } else {
                        MidrpObj.setCount(MidrpObj.getCount() + 1);
                        MidrpObj.setLastValue(value);
                        if (value instanceof Number) {
                            Double doubleValue = new Double(value.toString());
                            MidrpObj.setMinValue(Math.min(MidrpObj.getMinValue(), doubleValue));
                            MidrpObj.setMaxValue(Math.max(MidrpObj.getMaxValue(), doubleValue));
                            MidrpObj.setSumValue(MidrpObj.getSumValue() + doubleValue);
                            MidrpObj.setAvgValue((MidrpObj.getSumValue()) / MidrpObj.getCount());
                        }
                    }
                    aggregateTagMap.put(key, MidrpObj);

                }

            }

        } catch (JSONException err) {
            logger.error("message received not has valid json format.");
        } catch (Exception err) {
            logger.error("[error detail]: " + err.getMessage());
        }
    }
}
