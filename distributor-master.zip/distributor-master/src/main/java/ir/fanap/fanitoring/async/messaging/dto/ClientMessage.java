/**
 * Copyright (c) 2015-2017 Fanap ICT Holding. All Rights Reserved.
 */

package ir.fanap.fanitoring.async.messaging.dto;

/**
 * @author h.mehrara on 1/29/2015.
 * Edited by Mohsen Ebrahimi 2/25/2017
 */
public class ClientMessage {

	private long id;
	private Long senderMessageId;
	private String senderName;
	private long senderId;
	private byte type;
	private String content;//RestRequest in json format in restOverAsync mode.
	private String address;
	private Long trackerId;
	private String origin;

	@Override
	public int hashCode() {
		int result = (int) (getId() ^ (getId() >>> 32));
		result = 31 * result + (int) (getSenderMessageId() ^ (getSenderMessageId() >>> 32));
		result = 31 * result + (getSenderName() != null ? getSenderName().hashCode() : 0);
		result = 31 * result + (int) (getSenderId() ^ (getSenderId() >>> 32));
		result = 31 * result + (int) getType();
		result = 31 * result + (getContent() != null ? getContent().hashCode() : 0);
		result = 31 * result + (getAddress() != null ? getAddress().hashCode() : 0);
		result = 31 * result + (getOrigin() != null ? getOrigin().hashCode() : 0);
		result = 31 * result + (int) (getTrackerId() ^ (getTrackerId() >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object o) {
		boolean result;
		if (this == o) {
			return true;
		}
		if (!(o instanceof ClientMessage)) {
			return false;
		}

		ClientMessage that = (ClientMessage) o;

		result = (getId() != that.getId())
				&& (!getSenderMessageId().equals(that.getSenderMessageId()))
				&& (getSenderId() != that.getSenderId())
				&& (getType() != that.getType())
				&& (getSenderName() != null ? !getSenderName().equals(that.getSenderName()) : that.getSenderName() != null)
				&& (getContent() != null ? getContent().equals(that.getContent()) : that.getContent() == null)
				&& (getAddress() != null ? getAddress().equals(that.getAddress()) : that.getAddress() == null)
				&& (getOrigin() != null ? getOrigin().equals(that.getOrigin()) : that.getOrigin() == null)
				&& (!getTrackerId().equals(that.getTrackerId()));
		return result;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getSenderMessageId() {
		return senderMessageId;
	}

	public void setSenderMessageId(Long senderMessageId) {
		this.senderMessageId = senderMessageId;
	}

	public String getSenderName() {
		return senderName;
	}

	public long getSenderId() {
		return senderId;
	}

	public void setSenderId(long senderId) {
		this.senderId = senderId;
	}

	public byte getType() {
		return type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public Long getTrackerId() {
		return trackerId;
	}

	public void setTrackerId(Long trackerId) {
		this.trackerId = trackerId;
	}

	public void setType(byte type) {
		this.type = type;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
}
