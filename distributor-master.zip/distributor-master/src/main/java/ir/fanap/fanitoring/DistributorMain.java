package ir.fanap.fanitoring;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource("http://localhost/distributor-config.properties")
public class DistributorMain {

    private final static Logger logger = LogManager.getLogger(DistributorMain.class);

    public static void main(String[] args)  {
        logger.info("Distributor is being prepared for start");
        SpringApplication.run(DistributorMain.class, args);
        logger.info("[Distributor] Service started successfully ...");
    }


}
