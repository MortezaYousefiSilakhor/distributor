package ir.fanap.fanitoring.mqtt;

import ir.fanap.fanitoring.redis.RedisSubscriber;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Service
@Configurable
@ConditionalOnProperty(name = "mqttSender.enabled", havingValue = "true")
public class MQTTPublisher {

    private static final Logger logger = LogManager.getLogger(MQTTPublisher.class);

    @Value("${mqtt.topic}")
    private String mqttTopic;

    @Value("${mqtt.server.url}")
    private String mqttServerUrl;

    public MqttAsyncClient myClient;

    @PostConstruct
    public void init() {
        try {
            myClient = new MqttAsyncClient(mqttServerUrl, UUID.randomUUID().toString());
            MQTTCallBack myCallBack = new MQTTCallBack();
            myClient.setCallback(myCallBack);
            IMqttToken token = null;
            token = myClient.connect();
            token.waitForCompletion();
        } catch (MqttException e) {
            logger.error("error occurred in mqtt publisher init. [detail]=" + e.getMessage());
        }

    }

    public void publish(String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes(StandardCharsets.UTF_8));
            myClient.publish(mqttTopic, mqttMessage);
        } catch (MqttException e) {
            logger.error("error occurred in mqtt publisher method. [detail]=" + e.getMessage());

        }

    }
}
