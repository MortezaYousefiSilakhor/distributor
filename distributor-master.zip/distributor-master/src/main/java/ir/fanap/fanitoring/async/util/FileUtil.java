package ir.fanap.fanitoring.async.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * @author Alieh Mohtashami on 10/11/17.
 */
public class FileUtil {
	private final static Logger logger = LogManager.getLogger(FileUtil.class);

	public static void writeCsvFile(String fileName, String delemeter, ArrayList... rows) throws Exception {
		String content = "";
		for (int i = 0; i < rows.length; ++i) {
			ArrayList<String> currentRow = rows[i];
			for (int j = 0; j < currentRow.size() - 1; ++j)
				content += currentRow.get(j) + delemeter;
			content += currentRow.get(currentRow.size() - 1) + "\n";
		}
		writeInFile(fileName, content);
	}

	public static void writeInFile(String filename, String content) throws Exception {
		BufferedWriter out = new BufferedWriter(new FileWriter(filename, false));
		out.write(content + "\n");
		out.close();
	}

	public static void writeInFile(String filename, String content, boolean append) throws Exception {
		BufferedWriter out = new BufferedWriter(new FileWriter(filename, append));
		out.write(content + "\n");
		out.close();
	}

	public static Boolean checkIfFileExists(String filePath) {
		return new File(filePath).exists();
	}

	public static void deleteFile(String filePath) {
		File file = new File(filePath);
		file.deleteOnExit();
	}

	public static void deleteFilesWithAPrefix(String folder, String prefix) {

		GenericPrefixFilter filter = new GenericPrefixFilter(prefix);
		File dir = new File(folder);

		//list out all the file name with .txt extension
		String[] list = dir.list(filter);

		if (list.length == 0) return;

		File fileDelete;

		for (String file : list) {
			String temp = new StringBuffer(folder)
					.append(File.separator)
					.append(file).toString();
			fileDelete = new File(temp);
			boolean isdeleted = fileDelete.delete();
			logger.info("file : " + temp + " is deleted : " + isdeleted);
		}
	}

	public static String retrieveFileContent(String fileName) throws IOException {
		File file = new File(fileName);
		if (file.exists()) {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line, currentContent = "";
			while ((line = reader.readLine()) != null) {
				currentContent += line + "\r\n";
			}
			reader.close();
			return currentContent;
		} else return null;

	}

	public static JSONObject getJsonFileContent(String filename) {
		try {
			Resource resource = new ClassPathResource(filename);
			InputStream inputStream = resource.getInputStream();
			byte[] bdata = FileCopyUtils.copyToByteArray(inputStream);
			String data = new String(bdata, StandardCharsets.UTF_8);
			JSONObject jsonObject = new JSONObject(data);
			return jsonObject;
		} catch (IOException e) {
			logger.error("Error in read " + filename + " file.");
			return null;
		} catch (JSONException e) {
			logger.error("Error in cast " + filename + " file content to json format.");
			return null;
		}
	}

	//inner class, generic extension filter
	public static class GenericPrefixFilter implements FilenameFilter {

		private String prefix;

		public GenericPrefixFilter(String ext) {
			this.prefix = ext;
		}

		public boolean accept(File dir, String name) {
			return (name.startsWith(prefix));
		}

	}
}
